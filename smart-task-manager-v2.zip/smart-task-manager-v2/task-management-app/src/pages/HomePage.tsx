import App from "src/App";
const HomePage = () => <App />;
export default HomePage;
