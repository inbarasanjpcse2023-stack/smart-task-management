import React from 'react';
import { ITextInput } from './ITextInput';
import "./TextInput.css";
const TextInput: React.FC<ITextInput> = ({ label, placeholder, value, onChange }) => (
  <div className="inputContainer">
    <label className="labelStyle">{label}</label>
    <input className="input" type="text" placeholder={placeholder} value={value} onChange={e => onChange(e.target.value)} />
  </div>
);
export default TextInput;
