import { useState } from "react";
import Header from "src/components/Header/Header";
import TaskForm from "src/components/TaskForm/TaskForm";
import TaskList from "src/components/TaskList/TaskList";
import PieChart from "src/components/PieChart/PieChart";
import BarGraph from "src/components/BarGraph/BarGraph";
import { ITaskHomeProps } from "./ITaskHomeProps";
import { COMMON_TEXT } from "src/helper/constants";
import { getDaysLeft } from "src/helper/helperFunc";
import "./TaskHome.css";

const TaskHome = ({ tasks, setTasks }: { tasks: ITaskHomeProps[]; setTasks: React.Dispatch<React.SetStateAction<ITaskHomeProps[]>> }) => {
  const [activeTab, setActiveTab] = useState<'board' | 'analytics'>('board');
  const all = tasks.flatMap(t => t.items);
  const completed = tasks.find(t => t.status === 'COMPLETED')?.items?.length || 0;
  const started = tasks.find(t => t.status === 'STARTED')?.items?.length || 0;
  const total = all.length;
  const rate = total ? Math.round(completed / total * 100) : 0;
  const overdueItems = all.filter(i => (getDaysLeft(i.dueDate) as number) < 0);

  return (
    <div>
      <Header
        title={COMMON_TEXT.TITLE}
        taskCount={total}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
      <div className="pageLayout">
        <aside className="sidebar">
          <TaskForm tasks={tasks} setTasks={setTasks} />
          <div className="quickStatsCard">
            <div className="quickStatsTitle">Quick Stats</div>
            <div className="quickStatsGrid">
              <div className="qStat"><div className="qNum">{total}</div><div className="qLbl">Total</div></div>
              <div className="qStat"><div className="qNum">{completed}</div><div className="qLbl">Done</div></div>
              <div className="qStat"><div className="qNum">{rate}%</div><div className="qLbl">Rate</div></div>
              <div className="qStat"><div className="qNum" style={overdueItems.length ? { color: 'var(--red)' } : {}}>{overdueItems.length}</div><div className="qLbl">Overdue</div></div>
            </div>
          </div>
          {overdueItems.length > 0 && (
            <div className="overdueCard">
              <div className="overdueTitle">⚠ Overdue Tasks</div>
              {overdueItems.map(i => (
                <div key={i.id} className="overdueItem">
                  <span style={{ textTransform: 'capitalize', color: 'var(--ink2)' }}>{i.name}</span>
                  <span style={{ color: 'var(--red)' }}>{Math.abs(getDaysLeft(i.dueDate) as number)}d ago</span>
                </div>
              ))}
            </div>
          )}
        </aside>
        <main className="mainContent">
          {activeTab === 'board' && <TaskList tasks={tasks} setTasks={setTasks} />}
          {activeTab === 'analytics' && (
            <div>
              <PieChart graphData={tasks} />
              <BarGraph graphData={tasks} />
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default TaskHome;
